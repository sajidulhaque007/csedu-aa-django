from .sent_emails import SystemMail, SystemMailManager, UserMail, UserMailManager
from .email import CommonEmailAddress