from events.models.events import EventManager
